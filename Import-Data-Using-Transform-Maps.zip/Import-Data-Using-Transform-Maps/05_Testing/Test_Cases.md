# Test Cases

## Contents

- [TC-01: Spreadsheet preparation](#tc-01-spreadsheet-preparation)
- [TC-02: Custom table creation](#tc-02-custom-table-creation)
- [TC-03: Import Set creation](#tc-03-import-set-creation)
- [TC-04: Transform Map creation](#tc-04-transform-map-creation)
- [TC-05: Field mapping](#tc-05-field-mapping)
- [TC-06: Successful transform](#tc-06-successful-transform)
- [TC-07: Coalesce update](#tc-07-coalesce-update)
- [TC-08: Duplicate prevention](#tc-08-duplicate-prevention)
- [TC-09: Reports](#tc-09-reports)
- [TC-10: Dashboard](#tc-10-dashboard)

Run these checks in the ServiceNow instance with valid test data. The supplied project reference provides expected counts for the repeat import but does not include a complete employee dataset.

## TC-01: Spreadsheet preparation

**Steps:** Prepare employee data with Employee ID, Employee Name, Email, Department, and Location. Download as `Sample Spreadsheet.xlsx`.

**Expected result:** The workbook opens and contains the five required columns and intended data rows. The import copy has no unresolved placeholders.

## TC-02: Custom table creation

**Steps:** Create Employee Test (`u_employee_test`) and add Employee ID, Employee Name, Email, Department, and Location as String fields.

**Expected result:** The table is saved and all five fields appear on its form.

## TC-03: Import Set creation

**Steps:** Use Application Navigator → Load Data to load the spreadsheet. Set the Label to Employee Import and submit.

**Expected result:** Employee Import is created with auto-populated name `u_employee_import` and loaded spreadsheet data.

## TC-04: Transform Map creation

**Steps:** Create the Sample Spreadsheet Import Transform Map with source Employee Import and target Employee Test. Save it.

**Expected result:** The saved map has the specified source and target tables.

## TC-05: Field mapping

**Steps:** Use Auto Map Matching Fields and Mapping Assist to map source fields to target fields.

**Expected result:** The source employee fields map to the corresponding Employee Test fields: Employee ID, Employee Name, Email, Department, and Location.

## TC-06: Successful transform

**Steps:** Run Transform on the loaded Import Set data and review the result.

**Expected result:** Transformation completes successfully, and the imported records can be checked in Employee Test.

## TC-07: Coalesce update

**Steps:** Set Coalesce to True for the Employee ID Field Map. Re-import a row with an Employee ID that already exists and updated employee data.

**Expected result:** The matching Employee Test record is updated instead of creating another record with the same Employee ID. The project reference gives email `test10@gmail.com` changing to `test18@gmail.com` and employee name `Ajay kumar` changing to `Ajay` as examples; use the supplied values only where they are part of the available test data.

## TC-08: Duplicate prevention

**Steps:** Import the same four-row Excel data again using Employee Import and run the existing Transform Map. Review Transform History and Employee Test.

**Expected result:** 4 rows uploaded, 0 inserted, 0 updated, and 4 ignored. No duplicate employee records are created because Coalesce identifies existing Employee IDs.

## TC-09: Reports

**Steps:** Create and run all three reports on Employee Test: Employees by Department (pie chart, group by Department, Count); Employees by Location (bar chart, group by Location, Count); Employee List Report (list with the five requested columns).

**Expected result:** All reports are saved and run with the configured types, groups, aggregation, and columns.

## TC-10: Dashboard

**Steps:** Create Employee Analytics Dashboards. Use Share → Add to Dashboards for each of the three reports.

**Expected result:** The dashboard contains Employees by Department, Employees by Location, and Employee List Report.

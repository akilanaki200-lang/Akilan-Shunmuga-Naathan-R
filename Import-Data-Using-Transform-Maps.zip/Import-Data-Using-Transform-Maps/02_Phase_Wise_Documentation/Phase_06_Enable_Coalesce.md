# Phase 6: Enable Coalesce to Avoid Duplicate Records

## Objective

Use Employee ID to identify existing employee records so that re-imported data updates records rather than creating duplicates.

## Navigation

Open the Transform Map named `Sample Spreadsheet Import`, then open its **Field Maps** related list.

## Prerequisites

- The `Sample Spreadsheet Import` Transform Map exists.
- Employee ID is mapped between the source and target fields.
- Employee Test contains records from the earlier transform.

## Step-by-step procedure

1. Open the created Transform Map named `Sample Spreadsheet Import`.
2. Open the **Field Maps** related list.
3. Set **Coalesce** to `True` for the Employee ID field.
4. Save.
5. Prepare additional Excel data for testing.
6. Re-import the data.
7. Verify that existing employees are updated instead of duplicated.

## Configuration values

| Field Map setting | Value |
|---|---|
| Field | Employee ID |
| Coalesce | `True` |

## Expected result

Employee ID is used to match incoming rows to existing Employee Test records. Matching records can be updated rather than duplicated.

## Verification

After re-importing the additional test data, check the target records and confirm matching Employee IDs update existing employees. Phase 7 describes the supplied example results.

## Screenshot placeholder/reference

Add screenshots showing the Employee ID Field Map with Coalesce set to True and the re-import/update result, as described in the [Screenshot Guide](../04_Screenshots/README.md#phase-6-enable-coalesce).

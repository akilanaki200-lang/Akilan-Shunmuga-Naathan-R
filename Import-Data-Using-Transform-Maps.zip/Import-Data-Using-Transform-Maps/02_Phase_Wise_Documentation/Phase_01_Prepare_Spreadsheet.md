# Phase 1: Prepare the Sheets

## Objective

Prepare employee data in a spreadsheet and download it as an Excel workbook for the ServiceNow import.

## Navigation

Open Google Spreadsheet and create a new spreadsheet.

## Prerequisites

- Access to Google Spreadsheet.
- Employee data to import. No actual employee dataset was provided with this documentation; use clearly identified placeholders until real values are available.

## Step-by-step procedure

1. Open a new Google Spreadsheet.
2. Create sample employee data with columns for Employee ID, Employee Name, Email, Department, and Location.
3. Use the [CSV template](../03_Source_Files/Employee_Data.csv) as a starting point if useful. Replace every placeholder with valid project data before importing.
4. Download the spreadsheet in `Sample Spreadsheet.xlsx` format.

## Configuration values

| Setting | Value |
|---|---|
| Workbook name | `Sample Spreadsheet.xlsx` |
| Data columns | Employee ID, Employee Name, Email, Department, Location |

## Expected result

An Excel workbook named `Sample Spreadsheet.xlsx` is ready to load into ServiceNow. The CSV in this repository is a placeholder template, not that workbook.

## Verification

Open the downloaded workbook and confirm that it contains the five employee columns and the rows intended for import. Confirm that no placeholder values remain in the import copy.

## Screenshot placeholder/reference

Add a screenshot of the prepared spreadsheet and downloaded workbook evidence as described in the [Screenshot Guide](../04_Screenshots/README.md#phase-1-prepare-the-spreadsheet).

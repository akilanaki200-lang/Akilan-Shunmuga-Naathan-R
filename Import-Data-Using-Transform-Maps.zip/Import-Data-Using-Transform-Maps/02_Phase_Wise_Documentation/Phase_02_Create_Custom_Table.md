# Phase 2: Create New Custom Table

## Objective

Create the `Employee Test` target table and add the five employee fields used by the import.

## Navigation

Go to **Tables > Create New**.

## Prerequisites

- Access to the ServiceNow instance.
- Phase 1 spreadsheet columns identified: Employee ID, Employee Name, Email, Department, and Location.

## Step-by-step procedure

1. Open **Tables > Create New**.
2. Create the table using the configuration below and save it.
3. Scroll to the bottom of the table form and click **Show Form**.
4. Open **Form Context Menu / Additional Actions**.
5. Select **Configure → Form Layout**.
6. Click **New** to create fields.
7. Create each field listed below as a String field.
8. Save and verify that all fields appear on the Employee Test form.

## Configuration values

| Setting | Value |
|---|---|
| Label | `Employee Test` |
| Name | `u_employee_test` |
| Field: Employee ID | String |
| Field: Employee Name | String |
| Field: Email | String |
| Field: Department | String |
| Field: Location | String |

## Expected result

The `Employee Test` table is created with the five listed String fields available on its form.

## Verification

Open the Employee Test form and confirm Employee ID, Employee Name, Email, Department, and Location are present.

## Screenshot placeholder/reference

Add screenshots of the saved table and the form showing all five fields, as described in the [Screenshot Guide](../04_Screenshots/README.md#phase-2-create-the-custom-table).

# Phase 3: Create Import Set Table

## Objective

Load spreadsheet data into an Import Set table that acts as the staging area for transformation.

## Navigation

Open **Application Navigator → Load Data**.

## Prerequisites

- The `Employee Test` target table exists.
- The spreadsheet is prepared as described in [Phase 1](Phase_01_Prepare_Spreadsheet.md).
- Replace all CSV or spreadsheet placeholders with actual employee data before upload.

## Step-by-step procedure

1. Open **Application Navigator → Load Data**.
2. Select and load the spreadsheet data.
3. Create an import table using the configuration below.
4. Submit.
5. After submitting, create the Transform Map as described in [Phase 4](Phase_04_Create_Transform_Map.md).

## Configuration values

| Setting | Value |
|---|---|
| Label | `Employee Import` |
| Name | `u_employee_import` (auto populated) |

## Expected result

The spreadsheet data is staged in the `Employee Import` table, whose name is auto populated as `u_employee_import`.

## Verification

Confirm the submitted load created the `Employee Import` table. Continue to Transform Map creation after submission.

## Screenshot placeholder/reference

Add a screenshot of the Load Data configuration and submitted Import Set table, as described in the [Screenshot Guide](../04_Screenshots/README.md#phase-3-create-the-import-set-table).

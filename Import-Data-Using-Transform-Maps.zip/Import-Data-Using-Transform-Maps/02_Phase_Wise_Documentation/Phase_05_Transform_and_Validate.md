# Phase 5: Transform Data & Validate

## Objective

Confirm that transformed employee records are available in Employee Test and can be viewed in the required column order.

## Navigation

Open the `Employee Test` table from **Application Navigator**.

## Prerequisites

- The Phase 4 Transform Map has been run.
- Employee Test contains the five fields created in Phase 2.

## Step-by-step procedure

1. Open the Employee Test table from Application Navigator.
2. Use **Personalize List Columns**.
3. Arrange the columns in the order listed below.
4. Review the imported records.

## Configuration values

| List column order |
|---|
| Employee ID |
| Employee Name |
| Email |
| Department |
| Location |

## Expected result

Imported employee records are visible in Employee Test with all five columns arranged in the requested order.

## Verification

Check the imported records and confirm the displayed Employee ID, Employee Name, Email, Department, and Location values correspond to the spreadsheet rows.

## Screenshot placeholder/reference

Add a screenshot of the Employee Test list with all five columns and imported records, as described in the [Screenshot Guide](../04_Screenshots/README.md#phase-5-transform-data-and-validate).

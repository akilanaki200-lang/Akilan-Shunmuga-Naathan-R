# Phase 9: Add Reports to Dashboard

## Objective

Create the Employee Analytics Dashboards dashboard and add the three saved reports.

## Navigation

Use **All → Dashboards**. The reference also uses the backend form `PA_DASHBOARDS.FORM` and describes enabling Admin Overrides for the `pa_dashboards` Create operation ACL when required.

## Prerequisites

- The three reports from Phase 8 are saved:
  - Employees by Department
  - Employees by Location
  - Employee List Report
- Access needed to create a dashboard. If dashboard creation requires it in the instance, follow the reference's Admin Overrides guidance for the `pa_dashboards` Create operation ACL.

## Step-by-step procedure

1. Open **All → Dashboards**.
2. Create a dashboard with the name shown below.
3. If necessary, use the `PA_DASHBOARDS.FORM` backend form described by the project reference.
4. If dashboard creation requires an ACL override, enable Admin Overrides for the `pa_dashboards` Create operation ACL as referenced.
5. Open each of the three reports.
6. For each report, use **Share → Add to Dashboards** and add it to the created dashboard.
7. Open the dashboard and confirm it contains all three reports.

## Configuration values

| Setting | Value |
|---|---|
| Dashboard name | `Employee Analytics Dashboards` |
| Reports | Employees by Department; Employees by Location; Employee List Report |

## Expected result

The Employee Analytics Dashboards dashboard contains all three reports.

## Verification

Open the dashboard and confirm the department pie chart, location bar chart, and employee list report are all present.

## Screenshot placeholder/reference

Add screenshots of the dashboard and its three reports, as described in the [Screenshot Guide](../04_Screenshots/README.md#phase-9-add-reports-to-dashboard).

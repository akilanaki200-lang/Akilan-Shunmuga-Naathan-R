# Phase 8: Create Reports on Employee Test Table

## Objective

Create two employee-count charts and one employee list report using the Employee Test table.

## Navigation

Create each report using the ServiceNow reporting interface available in the instance. The supplied project description does not specify a more detailed navigation path.

## Prerequisites

- `Employee Test` contains the employee records to report on.
- Department, Location, and the other list fields are available on the table.

## Step-by-step procedure

1. Create the Employees by Department report using the first configuration below.
2. Run and save the report.
3. Create the Employees by Location report using the second configuration below.
4. Run and save the report.
5. Create the Employee List Report using the third configuration below.
6. Run and save the report.

## Configuration values

| Report | Source Type | Table | Type | Group By | Aggregation / Columns |
|---|---|---|---|---|---|
| Employees by Department | Table | Employee Test | Pie Chart | Department | Count |
| Employees by Location | Table | Employee Test | Bar Chart | Location | Count |
| Employee List Report | Table | Employee Test | List | Not specified | Employee ID, Employee Name, Email, Department, Location |

## Expected result

All three reports are saved and run: a pie chart of employee counts by department, a bar chart of employee counts by location, and a list of employee details.

## Verification

Run each saved report. Confirm chart groupings and counts use the specified fields, and confirm the list report shows the five requested columns.

## Screenshot placeholder/reference

Add a screenshot of each saved report, as described in the [Screenshot Guide](../04_Screenshots/README.md#phase-8-create-reports).

# Phase 4: Create Transform Map

## Objective

Create a Transform Map that maps the Employee Import staging data to the Employee Test target table and run it.

## Navigation

Create the Transform Map after submitting the Load Data form in [Phase 3](Phase_03_Create_Import_Set_Table.md).

## Prerequisites

- `Employee Import` (`u_employee_import`) exists and contains loaded spreadsheet rows.
- `Employee Test` (`u_employee_test`) exists with all five target fields.

## Step-by-step procedure

1. Create a Transform Map using the configuration below.
2. Use **Auto Map Matching Fields**.
3. Use **Mapping Assist** to map the source table fields to the target table fields.
4. Save the Transform Map.
5. Run Transform.
6. Verify that transformation completes successfully.

## Configuration values

| Setting | Value |
|---|---|
| Name | `Sample Spreadsheet Import` |
| Source Table | `Employee Import` |
| Target Table | `Employee Test` |
| Mapping | Auto Map Matching Fields, then Mapping Assist |

## Expected result

The saved Transform Map maps source data to Employee Test, and the transform completes successfully.

## Verification

Check the transform result and confirm it reports a successful transformation. Verify the resulting records in the target table in [Phase 5](Phase_05_Transform_and_Validate.md).

## Screenshot placeholder/reference

Add screenshots of the Transform Map configuration, field mapping, and successful transform, as described in the [Screenshot Guide](../04_Screenshots/README.md#phase-4-create-the-transform-map).

# Phase 7: Insert New Data in Excel Format

## Objective

Import additional Excel data into the existing Import Set table, run the existing Transform Map, and verify updates, inserts, and duplicate prevention on a repeated import.

## Navigation

Use **All → Load Data** under **System Import Set**.

## Prerequisites

- `Employee Import` exists.
- The `Sample Spreadsheet Import` Transform Map exists and Employee ID Coalesce is set to `True`.
- Prepare an Excel file with four test rows. The actual employee IDs and most row values were not provided; use real test data rather than invented values.

## Step-by-step procedure

1. Open **All → Load Data** under System Import Set.
2. Select the existing Import Set Table: `Employee Import`.
3. Set Source to **Select File**.
4. Set Sheet number to `1`.
5. Set Header row to `1`.
6. Submit.
7. Run the existing Transform Map.
8. Check **Transform History**.
9. Verify the inserted and updated records.
10. Open Employee Test and verify the changes.
11. Repeat the same import using the same Excel data.
12. Check Transform History again and verify the expected repeat-import result below.

## Configuration values

| Setting | Value |
|---|---|
| Import Set Table | `Employee Import` |
| Source | Select File |
| Sheet number | `1` |
| Header row | `1` |
| Rows in the described test upload | `4` |

The supplied project reference describes two existing employee records updated and two new Employee IDs inserted on the first additional import. It also gives these example changes: email from `test10@gmail.com` to `test18@gmail.com`, and employee name from `Ajay kumar` to `Ajay`. The related Employee IDs and other values were not supplied.

## Expected result

For the first additional import, the reference describes four rows uploaded, two existing employee records updated, and two new Employee IDs inserted. Verify the actual counts shown by Transform History in the instance.

For the second import of the same Excel data, the expected result is:

| Result | Count |
|---|---:|
| Uploaded | 4 |
| Inserted | 0 |
| Updated | 0 |
| Ignored | 4 |

This happens because the same data was imported again and Coalesce identifies the existing records.

## Verification

- Check Transform History after each transform.
- For the first additional import, confirm the insert/update outcomes and inspect the changed records in Employee Test.
- For the repeat import, confirm four rows uploaded, zero inserted, zero updated, and four ignored.
- Verify that no duplicate Employee ID records were created.

## Screenshot placeholder/reference

Add screenshots of Load Data settings, the first Transform History result, updated/inserted records, the repeat-import history, and Employee Test validation, as described in the [Screenshot Guide](../04_Screenshots/README.md#phase-7-insert-new-data).

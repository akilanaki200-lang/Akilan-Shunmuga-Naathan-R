# Project Overview: Import Data using Transform Maps (Spreadsheet)

## Contents

- [Purpose](#purpose)
- [Objectives](#objectives)
- [Scope and workflow](#scope-and-workflow)
- [ServiceNow components](#servicenow-components)
- [Expected outcome](#expected-outcome)
- [Project files](#project-files)

## Purpose

This micro project imports structured employee data from an external spreadsheet into ServiceNow. The data is loaded into an Import Set table, which serves as a staging area. A Transform Map connects source fields to fields in a target table. Running the transform creates or updates target records, which are then checked.

## Objectives

- Prepare employee data in a spreadsheet.
- Create a custom target table named `Employee Test` (`u_employee_test`).
- Create an Import Set table named `Employee Import` (`u_employee_import`).
- Map source fields to target fields with a Transform Map named `Sample Spreadsheet Import`.
- Verify transformed records and use Employee ID as the coalesce field.
- Create three reports and place them on a dashboard.

## Scope and workflow

The work is documented in nine numbered phases:

1. Prepare the spreadsheet.
2. Create the custom target table and fields.
3. Create the Import Set table by loading the spreadsheet.
4. Create the Transform Map, map fields, and run the transform.
5. Validate the records in the target table.
6. Enable Coalesce on Employee ID.
7. Import more data to test updates, inserts, and repeat-import behavior.
8. Create department, location, and employee-list reports.
9. Create a dashboard and add the reports.

## ServiceNow components

The supplied project description uses ServiceNow Tables, Application Navigator / Load Data, Import Sets, Transform Maps, Auto Map Matching Fields, Mapping Assist, Field Maps, Coalesce, Transform History, Personalize List Columns, Reports, Dashboards, report sharing, and (when required) an Admin Override for the `pa_dashboards` Create operation ACL.

## Expected outcome

Employee spreadsheet rows are staged in `Employee Import` and transformed into `Employee Test`. With Coalesce set on Employee ID, existing records can be updated instead of duplicated. Repeating an unchanged import is expected to produce four uploaded rows, zero inserted, zero updated, and four ignored. The project also produces three reports displayed together on **Employee Analytics Dashboards**.

## Project files

- Start with the repository [README](../README.md).
- Follow the [nine phase documents](../02_Phase_Wise_Documentation/Phase_01_Prepare_Spreadsheet.md).
- Find the CSV template and export guidance in [Source Files](../03_Source_Files/README.md).
- Use the [Screenshot Guide](../04_Screenshots/README.md) to record evidence for each phase.
- Run the checks in [Test Cases](../05_Testing/Test_Cases.md).

Only the project details supplied for this micro project are documented here. The CSV contains placeholders; the actual spreadsheet, screenshots, and Update Set XML must be prepared or exported by the project owner.

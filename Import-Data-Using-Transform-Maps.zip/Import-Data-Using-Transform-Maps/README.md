# Import Data using Transform Maps (Spreadsheet)

## Project Overview

This ServiceNow micro project demonstrates how to import structured employee data from a spreadsheet using Import Sets and a Transform Map. Data is first loaded into a staging table, mapped to a custom target table, transformed, and validated. Coalesce is used to update existing employees and prevent duplicate records.

See the [project overview](01_Project_Overview/Project_Overview.md) for the full description.

## Objectives

- Prepare employee spreadsheet data for import.
- Create a custom employee table and an Import Set table.
- Map and transform source fields into the target table.
- Validate inserted and updated records.
- Use Employee ID coalescing to prevent duplicate records.
- Create reports and display them on a dashboard.

## Technologies and ServiceNow Features

- Google Spreadsheet / Excel spreadsheet file
- ServiceNow custom tables
- System Import Sets and Load Data
- Transform Maps, Auto Map Matching Fields, Mapping Assist, and Coalesce
- List personalization
- Reports and dashboards
- Update Set XML export (to be exported from the ServiceNow instance; not included yet)

## Project Workflow

1. Prepare spreadsheet data.
2. Create the `Employee Test` target table and its fields.
3. Load data into the `Employee Import` staging table.
4. Create and configure the Transform Map, then run it.
5. Validate the transformed employee records.
6. Enable Coalesce on Employee ID.
7. Re-import changed and new data, then repeat the import to verify duplicate prevention.
8. Create three reports.
9. Add the reports to the dashboard.

## Phase Summary

| Phase | Work |
|---|---|
| [Phase 1](02_Phase_Wise_Documentation/Phase_01_Prepare_Spreadsheet.md) | Prepare the spreadsheet |
| [Phase 2](02_Phase_Wise_Documentation/Phase_02_Create_Custom_Table.md) | Create the custom Employee Test table and fields |
| [Phase 3](02_Phase_Wise_Documentation/Phase_03_Create_Import_Set_Table.md) | Create the Employee Import Import Set table |
| [Phase 4](02_Phase_Wise_Documentation/Phase_04_Create_Transform_Map.md) | Create and run the Transform Map |
| [Phase 5](02_Phase_Wise_Documentation/Phase_05_Transform_and_Validate.md) | Validate transformed records |
| [Phase 6](02_Phase_Wise_Documentation/Phase_06_Enable_Coalesce.md) | Enable Coalesce to avoid duplicates |
| [Phase 7](02_Phase_Wise_Documentation/Phase_07_Insert_New_Data.md) | Test updates, inserts, and repeat-import behavior |
| [Phase 8](02_Phase_Wise_Documentation/Phase_08_Create_Reports.md) | Create reports |
| [Phase 9](02_Phase_Wise_Documentation/Phase_09_Create_Dashboard.md) | Create a dashboard and add reports |

## Reports Created

- **Employees by Department**: pie chart grouped by Department, counted.
- **Employees by Location**: bar chart grouped by Location, counted.
- **Employee List Report**: list showing Employee ID, Employee Name, Email, Department, and Location.

## Dashboard

Create **Employee Analytics Dashboards** and add all three reports using each report's **Share → Add to Dashboards** option. See [Phase 9](02_Phase_Wise_Documentation/Phase_09_Create_Dashboard.md) for the dashboard procedure.

## Testing

The test cases cover spreadsheet preparation, table and Import Set creation, Transform Map and field mapping, successful transformation, Coalesce updates, duplicate prevention, reports, and dashboard contents. See [Test Cases](05_Testing/Test_Cases.md).

## Conclusion

The project demonstrates employee data import using ServiceNow Import Sets and Transform Maps. Coalesce prevents duplicate records and allows existing records to be updated. Reports and dashboards provide visual visibility into employee information.

## Folder Structure

```text
Import-Data-Using-Transform-Maps/
├── README.md
├── 01_Project_Overview/
│   └── Project_Overview.md
├── 02_Phase_Wise_Documentation/
│   ├── Phase_01_Prepare_Spreadsheet.md
│   ├── Phase_02_Create_Custom_Table.md
│   ├── Phase_03_Create_Import_Set_Table.md
│   ├── Phase_04_Create_Transform_Map.md
│   ├── Phase_05_Transform_and_Validate.md
│   ├── Phase_06_Enable_Coalesce.md
│   ├── Phase_07_Insert_New_Data.md
│   ├── Phase_08_Create_Reports.md
│   └── Phase_09_Create_Dashboard.md
├── 03_Source_Files/
│   ├── README.md
│   └── Employee_Data.csv
├── 04_Screenshots/
│   └── README.md
└── 05_Testing/
    └── Test_Cases.md
```

The CSV is a placeholder template, not the completed Excel workbook. Screenshots and the ServiceNow Update Set XML have not been supplied; add them only after capturing or exporting them from the ServiceNow instance. See [Source Files](03_Source_Files/README.md) and [Screenshot Guide](04_Screenshots/README.md).

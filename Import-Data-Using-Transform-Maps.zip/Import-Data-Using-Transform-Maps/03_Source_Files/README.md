# Source Files

This folder contains the employee data CSV template and is the designated location for source/export artifacts.

## Employee Data CSV

[Employee_Data.csv](Employee_Data.csv) has the five column headers used by the project and clearly marked placeholder values. Replace the placeholders with approved test data before using the file as an import source. The project reference does not provide a complete employee dataset.

The documented spreadsheet preparation step downloads a Google Spreadsheet as `Sample Spreadsheet.xlsx`. That workbook has not been supplied or generated here; prepare it in Google Spreadsheet using [Phase 1](../02_Phase_Wise_Documentation/Phase_01_Prepare_Spreadsheet.md).

## ServiceNow export

Export the actual ServiceNow Update Set XML from the ServiceNow instance and place the exported file in this folder. No XML is included because no instance export was provided. Do not treat the CSV template as an Update Set or an application export.
